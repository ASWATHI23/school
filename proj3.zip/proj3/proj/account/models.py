from django.db import models

# Create your models here.
class TeacherModel(models.Model):
     first=models.CharField(max_length=100)
     second=models.CharField(max_length=100)
     age=models.IntegerField()
     address=models.CharField(max_length=100)
     ph=models.IntegerField()
     email=models.EmailField()
     qualification=models.CharField(max_length=100)