from django.shortcuts import render,redirect
from django.views.generic import View
from django.http import HttpResponse
from .forms import RegForm,LoginForm
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout

# Create your views here.
class HomeView(View):
    def get(self,request,*args,**kwargs):
        us=request.user
        return render(request,"main_home.html",{"user":us})



class LogView(View):
     def get(self,request,*args,**kwargs):
         f=LoginForm()
         us=request.user
         return render(request,"login.html",{"form":f,"user":us})
     def post(self,request,*args,**kwargs):
        form_data=LoginForm(data=request.POST)
        if form_data.is_valid():
            un=form_data.cleaned_data.get("username")
            pd=form_data.cleaned_data.get("password")
            user=authenticate(request,username=un,password=pd)
            if user:
                login(request,user)
                messages.success(request,"login successfull")
                return redirect("h")
            else:
                messages.error(request,"login failed")
                return redirect("log")
        else:
            return render(request,"login.html",{"form":form_data})

class LogoutView(View):
    def get(self,request,*args,**kwargs):
        logout(request)
        return redirect("log")

    
        #  print(request.POST.get("uname"))
        #  print(request.POST.get("psw"))
        #  return HttpResponse("username:"+request.POST.get("uname")+"<br>password:"+request.POST.get("psw"))

class RegView(View):
    def get(self,request,*args,**kwargs):
        f=RegForm()
        return render(request,"regi.html",{"form":f})
    def post(self,request,*awrgs,**kwrgs):
        form_data=RegForm(data=request.POST)
        if form_data.is_valid():
            form_data.save()
            messages.success(request,"User registered successfully")
            return redirect("log")
        else:
             messages.error(request,"User registration failed")
             return render(request,"regi.html",{"form":form_data})

        # print(request.POST.get("fname"))
        # print(request.POST.get("lname"))
        # print(request.POST.get("email"))
        # print(request.POST.get("uname"))
        # print(request.POST.get("password"))
        # return HttpResponse("registerd")



