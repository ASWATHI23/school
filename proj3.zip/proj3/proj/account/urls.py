from django.urls import path
from .views import RegView,HomeView,LogoutView

urlpatterns = [
    path('reg/',RegView.as_view(),name="reg"),
    path('maho/',HomeView.as_view(),name="h"),
    path('lout/',LogoutView.as_view(),name="out")

]
