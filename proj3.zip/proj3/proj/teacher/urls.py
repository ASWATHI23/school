from django.urls import path
from .views import *

urlpatterns = [
    path('reg/',AddMarkView.as_view(),name="adm"),
    path('addst/',AddStudentMView.as_view(),name="ads"),
    path('vie/',ViewStudView.as_view(),name="vs"),
    path('delstu/<int:ssid>',StuDeleteView.as_view(),name="dls"),
    path('edstu/<int:sid>',StudentEditMView.as_view(),name="eds")

]