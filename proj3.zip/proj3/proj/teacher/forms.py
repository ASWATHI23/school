from django import forms
from.models import StudentModel

class AddMarkForm(forms.Form):
    s1=forms.IntegerField(label="enter sub1 mark")
    s2=forms.IntegerField(label="enter sub2 mark")
    s3=forms.IntegerField(label="enter sub3 mark")
    s4=forms.IntegerField(label="enter sub4 mark")
    s5=forms.IntegerField(label="enter sub5 mark")
    def clean(self):
        cleaned_data=super().clean()
        m1=cleaned_data.get("s1")
        m2=cleaned_data.get("s2")
        m3=cleaned_data.get("s3")
        m4=cleaned_data.get("s4")
        m5=cleaned_data.get("s5")
        if m1<0:
            msg="mark less than zero.Invalid input"
            self.add_error("s1",msg)
        if m2<0:
            msg="mark less than zero.Invalid input"
            self.add_error("s2",msg)
        if m3<0:
            msg="mark less than zero.Invalid input"
            self.add_error("s3",msg)
        if m4<0:
            msg="mark less than zero.Invalid input"
            self.add_error("s4",msg)
        if m5<0:
            msg="mark less than zero.Invalid input"
            self.add_error("s5",msg)


class AddStudentForm(forms.Form):
    first_name=forms.CharField(max_length=100,widget=forms.TextInput(attrs={"class":"form-control","placeholder":"enter your firstname"}))
    second_name=forms.CharField(max_length=100,widget=forms.TextInput(attrs={"class":"form-control","placeholder":"enter your secondname"}))
    age=forms.IntegerField(widget=forms.NumberInput(attrs={"class":"form-control","placeholder":"enter your age"}))
    address=forms.CharField(max_length=100,widget=forms.Textarea(attrs={"class":"form-control","placeholder":"enter your address"}))
    email=forms.EmailField(widget=forms.EmailInput(attrs={"class":"form-control","placeholder":"enter your email"}))
    phone=forms.IntegerField(widget=forms.NumberInput(attrs={"class":"form-control","placeholder":"enter your phonenumber"}))
    def clean(self):
        cleaned_data=super().clean()
        fn=cleaned_data.get("first_name")
        sn=cleaned_data.get("second_name")
        age=cleaned_data.get("age")
        ph=str(cleaned_data.get("phone"))
        if fn==sn:
            self.add_error("second_name","firstname and secondname are same" )
        if age<1:
            self.add_error("age","age is invalid")
        if len(ph)!=10:
            self.add_error("phone","invalid phone number")
        
class StudentMForm(forms.ModelForm):
    class Meta:
        model=StudentModel
        fields="__all__"
        widgets={
            "first":forms.TextInput(attrs={"class":"form-control","placeholder":"first name"}),
            "second":forms.TextInput(attrs={"class":"form-control","placeholder":"second name"}),
            "age":forms.NumberInput(attrs={"class":"form-control","placeholder":"age"}),
            "address":forms.Textarea(attrs={"class":"form-control","placeholder":"address"}),
            "email":forms.EmailInput(attrs={"class":"form-control","placeholder":"email"}),
            "ph":forms.NumberInput(attrs={"class":"form-control","placeholder":"phone"}),
            "image":forms.FileInput(attrs={"class":"form-control","placeholder":"image"})
        }
    def clean(self):
        cleaned_data=super().clean()
        fn=cleaned_data.get("first")
        sn=cleaned_data.get("second")
        age=cleaned_data.get("age")
        ph=str(cleaned_data.get("ph"))
        if fn==sn:
            self.add_error("second","firstname and secondname are same" )
        if age<1:
            self.add_error("age","age is invalid")
        if len(ph)!=10:
            self.add_error("ph","invalid phone number")
    


