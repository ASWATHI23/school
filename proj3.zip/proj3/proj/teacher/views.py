from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.views.generic import View
from .forms import AddMarkForm,AddStudentForm,StudentMForm
from django.contrib import messages
from .models import StudentModel
from django.utils.decorators import method_decorator

# Create your views here.
def signin_required(fun):
    def wrapper(request,*args,**kwargs):
        if request.user.is_authenticated:
            return fun(request,*args,**kwargs)
        else:
            messages.error(request,"you want to login first")
            return redirect("log")
    return wrapper


@method_decorator(signin_required,name='dispatch')
class AddMarkView(View):
    def get(self,request,*awrgs,**kwargs):
        f=AddMarkForm()
        return render(request,"addmark.html",{"form":f})
    def post(self,request,*awrgs,**kwrgs):
        form_data=AddMarkForm(data=request.POST)
        if form_data.is_valid():
         sub1=form_data.cleaned_data.get("s1")
         sub2=form_data.cleaned_data.get("s2")
         sub3=form_data.cleaned_data.get("s3")
         sub4=form_data.cleaned_data.get("s4")
         sub5=form_data.cleaned_data.get("s5")
         res=int(sub1)+int(sub2)+int(sub3)+int(sub4)+int(sub5)
         return render(request,"addmark.html",{"abc":res})
        else:
            return HttpResponse("invalid")

# class AddStudentView(View):
#      def get(self,request,*awrgs,**kwargs):
#         f=AddStudentForm()
#         return render(request,"addstu.html",{"form":f})

@method_decorator(signin_required,name='dispatch')
class AddStudentMView(View):
    def get(self,request,*awrgs,**kwargs):
        f=StudentMForm()
        return render(request,"addstu.html",{"form":f})
    def post(self,request,*awrgs,**kwargs):
        form_data=StudentMForm(data=request.POST,files=request.FILES)
        if form_data.is_valid():
            form_data.save()
            messages.success(request,"successfully add student")
            return redirect("vs")
        else:
            messages.success(request,"failed to add student")
            return render(request,"addstu.html",{"form":form_data})

@method_decorator(signin_required,name='dispatch')
class ViewStudView(View):
    def get(self,request,*awrgs,**kwargs):
        # if request.user.is_authenticated:
         res=StudentModel.objects.all()
         messages.success(request,"authentication success")
         return render(request,"view.html",{"data":res})
        # else:
        #      messages.error(request,"you want to login first")
        #      return redirect("log")

@method_decorator(signin_required,name='dispatch')
class StuDeleteView(View):
    def get(self,request,*awrgs,**kwargs):
        sid=kwargs.get("ssid")
        stu=StudentModel.objects.get(id=sid)
        stu.delete()
        return redirect("vs")

#class StuEditView(View):
 #   def get(self,request,*awrgs,**kwargs):
  #      id=kwargs.get("sid")
   #     stu=StudentModel.objects.get(id=id)
    #    f=AddStudentForm(initial={"first_name":stu.first,"second_name":stu.second,"age":stu.age,"address":stu.address,"email":stu.email,"phone":stu.ph})
     #   return render(request,"editstu.html",{"form":f})
    # def post(self,request,*awrgs,**kwargs):
      #   form_data=AddStudentForm(data=request.POST)
       #  if form_data.is_valid():
        #    fn=form_data.cleaned_data.get("first_name")
         #   sn=form_data.cleaned_data.get("second_name")
          #  age=form_data.cleaned_data.get("age")
           #ph=form_data.cleaned_data.get("phone")
            #em=form_data.cleaned_data.get("email")
           # add=form_data.cleaned_data.get("address")
            #id=kwargs.get("sid")
            #stu=StudentModel.objects.get(id=id)
            #stu.first=fn
            #stu.second=sn
          #  stu.age=age
           # stu.ph=ph
            #stu.email=em
          #  stu.address=add
           # stu.save()
            #messages.success(request,"successfully update student details")
           # return redirect("vs")
        # else:
         #   messages.success(request,"failed to update student details")
          #  return render(request,"editstu.html",{"form":form_data})
@method_decorator(signin_required,name='dispatch')
class StudentEditMView(View):
    def get(self,request,*awrgs,**kwargs):
        id=kwargs.get("sid")
        stu=StudentModel.objects.get(id=id)
        f=StudentMForm(instance=stu)
        return render(request,"editstu.html",{"form":f})
    def post(self,request,*awrgs,**kwargs):
       id=kwargs.get("sid")
       stu=StudentModel.objects.get(id=id)
       form_data=StudentMForm(data=request.POST,instance=stu,files=request.FILES)
       if form_data.is_valid():
        form_data.save()
        messages.success(request,"successfully update student details")
        return redirect("vs")
       else:
         messages.success(request,"failed to update student details")
         return render(request,"editstu.html",{"form":form_data})

     

