from django.db import models

# Create your models here.
class StudentModel(models.Model):
    first=models.CharField(max_length=100)
    second=models.CharField(max_length=100)
    age=models.IntegerField(null=True)
    address=models.CharField(max_length=100)
    ph=models.IntegerField(null=True)
    email=models.EmailField(null=True)
    image=models.ImageField(upload_to="student_images",null=True)
